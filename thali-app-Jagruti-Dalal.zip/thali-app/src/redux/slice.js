import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  value: "",
  products: [
    {
      id: 1,
      image:
        "https://images.unsplash.com/photo-1633442496018-6872fbfbbcc7?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
      name: "Chapati",
      price: "10",
    },

    {
      id: 2,
      image:
        "https://images.unsplash.com/photo-1589135233689-d56032e9680a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8cGlja2xlfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60",
      name: "Pickle",
      price: "5",
    },
    {
      id: 3,
      image:
        "https://media.istockphoto.com/photos/home-made-yogurt-in-clay-pot-picture-id1027715280?b=1&k=20&m=1027715280&s=170667a&w=0&h=BZu6MEUcdnI_4UuEFzD8wz5XqpD7pByrk4QmAEQYBVI=",
      name: "Curd",
      price: "20",
    },
    {
      id: 4,
      image:
        "https://media.istockphoto.com/photos/indian-dessert-gulab-jamun-in-white-bowl-picture-id1194711348?k=20&m=1194711348&s=612x612&w=0&h=jm6pRMqT8OcyA1WmMZhpL5y7Qd2eqtPeuFMKh_v61nI=",
      name: "Gulab Jamun",
      price: "50",
    },
    {
      id: 5,
      image:
        "https://media.istockphoto.com/photos/south-indian-vegetable-sambar-picture-id516595050?k=20&m=516595050&s=612x612&w=0&h=Gj5KZhXp7JRnfPKPNViHAZKrHVFto2Joal3ggRLoWDM=",
      name: "Daal",
      price: "20",
    },
    {
      id: 6,
      image:
        "https://media.istockphoto.com/photos/paneer-butter-masala-a-rich-and-creamy-indian-dish-made-of-paneer-or-picture-id1204449001?k=20&m=1204449001&s=612x612&w=0&h=VI3ZZgj-u0Quu2VVqfEKN0nA5Z0qRIo3oTQrzo7DX4c=",
      name: "Paneer Makhni",
      price: "150",
    },
    {
      id: 7,
      image:
        "https://media.istockphoto.com/photos/jeera-rice-is-a-popular-rice-dish-having-the-flavour-of-cumin-and-picture-id1352656313?k=20&m=1352656313&s=612x612&w=0&h=BhmAcXCUcm1dwrN3L-rEX2Y7N1IGu9ZzOghLP_BfoW8=",
      name: "Rice",
      price: "100",
    },
    {
      id: 8,
      image:
        "https://product-assets.faasos.io/production/product/image_1637670038753_Shaan%20Zaikedaar%20Paneer.jpg?d=500",
      name: "Paneer Dum Biryani",
      price: "597",
    },
    {
      id: 9,
      image:
        "https://media.istockphoto.com/photos/bowl-of-fresh-tomato-cucumber-salad-on-white-background-healthy-and-picture-id1219858263?k=20&m=1219858263&s=612x612&w=0&h=Fcjd6jiXq6mfdCrchfU6v3YijPjlWs_tNAjrZNd4A6s=",
      name: "Salad",
      price: "10",
    },
    {
      id: 11,
      image: "https://t3.ftcdn.net/jpg/02/76/15/38/240_F_276153839_yTyM0xu3LDOWjauZyaZaOygnBFeTNIMB.jpg",
      name: "Shev Bhaji",
      price: "50",
    },
    {
      id: 12,
      image: "https://3.bp.blogspot.com/_Z5_yoxEwtkE/TUl40DqM2vI/AAAAAAAADTY/zrnth7BSsfA/s1600/DSC04596.JPG",
      name: "Bharit Puri",
      price: "100",
    },
    {
      id: 13,
      image: "https://media.istockphoto.com/photos/pithla-or-pithla-bhakar-popular-recipe-from-maharashtra-picture-id880147644?b=1&k=20&m=880147644&s=170667a&w=0&h=HgcQOYFuKpIydanK7B58Sq46g6kpYA_jH04DhYC9xww=",
      name: "Pithla Bhakri",
      price: "80",
    },
    {
      id: 14,
      image: "http://punemisal.com/wp-content/uploads/2018/10/kf5-376x192.jpg",
      name: "Varan-Batti,bhaji",
      price: "100",
    },
    {
      id: 15,
      image: "https://madhurasrecipe.com/wp-content/uploads/2020/10/Dal-Gandori-Marathi-Recipe-post.jpg",
      name: "daal ganodri",
      price: "120",
    },
    {
      id: 16,
      image: "https://cdn.shopify.com/s/files/1/1012/9358/files/iStock-1141418070_large.jpg?v=1583487178",
      name: "Puran-Poli",
      price: "50",
    },
    {
      id: 17,
      image: "https://media.istockphoto.com/photos/alookanda-poha-or-tarri-pohe-with-spicy-chana-masalacurry-selective-picture-id1093257580?k=20&m=1093257580&s=612x612&w=0&h=txkv-V-olF9Hcbgry1RkOAx-pAIZOSOyE7uDBPkT4Yc=",
      name: "Pohe",
      price: "20",
    },
    {
      id: 18,
      image: "https://media.istockphoto.com/photos/upma-indian-breakfast-stock-image-picture-id1319623141?k=20&m=1319623141&s=612x612&w=0&h=pYR8TltEM_j-Ta_GugPadHQwIwUBhdmnhIdr1sUWm5g=",
      name: "Upma",
      price: "20",
    },
    {
      id: 19,
      image: "https://media.istockphoto.com/photos/masala-dosa-south-indian-food-picture-id909906350?k=20&m=909906350&s=612x612&w=0&h=lGGUz3p1-ILSWnEZtUFtqp7DVJmEW6AefTQQlZwR510=",
      name: "Dosa",
      price: "45",
    },
    {
      id: 20,
      image: "https://media.istockphoto.com/photos/vermicelli-upma-rice-noodles-picture-id1320485265?k=20&m=1320485265&s=612x612&w=0&h=NBvpo95GIA9LTfh_FuD9uV4N81C9Ssn25Y7ESIfvWiw=",
      name: "Shevaya",
      price: "35",
    },
    {
      id: 21,
      image: "https://media.istockphoto.com/photos/sambar-with-idliindian-dish-picture-id184721030?k=20&m=184721030&s=612x612&w=0&h=KEoqVt75g-mfpb5I28pRkAQjrQPYgF58QBVyVXtkV18=",
      name: "Idli,Sambar",
      price: "30",
    },
  ],
  thali: [],
};
export const counterSlice = createSlice({
  name: "counter",
  initialState,
  reducers: {
    addTothali: (state, action) => {
      state.thali.push(action.payload);
    },
    RemoveItem: (state, action) => {
      state.thali.splice(action.payload, 1);
    },
  },
});
export const { addTothali, RemoveItem } = counterSlice.actions;
export default counterSlice.reducer;