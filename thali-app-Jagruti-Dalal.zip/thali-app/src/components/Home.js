import React from "react";
import { useNavigate } from "react-router-dom";
const Home = () => {
  const navigate = useNavigate();
  return (
    <div className="home">
      <br />
      <h1>नमस्कार </h1>
      <br />
      <button
        onClick={() => {
          navigate("/Menu");
        }}
      >
        आपले आवडीचे पदार्थ
      </button>
    </div>
  );
};
export default Home;