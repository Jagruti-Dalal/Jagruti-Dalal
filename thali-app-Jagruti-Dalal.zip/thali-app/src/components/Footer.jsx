import React from "react";
import ReactDOM from 'react-dom';
import { SocialIcon } from 'react-social-icons';
import "./Footer.css";

const Footer = () => {
  return (
    <div className="footer">
      <footer>
        <div className="container">
          <div className="row">
            <div className="col-sm-6 col-md-3 item">
              <h3>We Deliever To</h3>
              <ul>
                <li>
                  <a href="#">Mumbai</a>
                </li>
                <li>
                  <a href="#">Banglore</a>
                </li>
                <li>
                  <a href="#">Pune</a>
                </li>
                <li>
                  <a href="#">Delhi</a>
                </li>
                <li>
                  <a href="#">Hyderabad</a>
                </li>
              </ul>
            </div>

            <div className="col-sm-6 col-md-3 item">
              <h3>SEE WHAT WE’RE UP TO</h3>
              <ul>
                <li>
                  <a href="#">Company</a>
                </li>
                <li>
                  <a href="#">Our Team</a>
                </li>
                <li>
                  <a href="#">Careers</a>
                </li>
                <li>
                  <a href="#">Privacy Policy</a>
                </li>
                <li>
                  <a href="#">help &amp; support</a>
                </li>
              </ul>
            </div>
            <div className="col-sm-6 col-md-3 item">
              <h3>Contact</h3>
              <p>
                {" "}
                Plot no.15, Aanad Nagar, Bijali Colony, Jalgaon – 425201,
                Maharashtra, India </p><p>+91 9649791770</p>
                  <p> khandeshithali@thali.com</p>
            
            </div>
            <div>
              <h1>Khandeshi Thali</h1>
              <p>
                Khandesh is a region of central India, which forms the
                northwestern portion of Maharashtra state.The region falls in
                north-west Maharashtra and covers Jalgaon, Dhule, Nandurbar,
                Malegaon, Nashik and Burhanpur in Madhya Pradesh. The Khandeshis
                like their meals spicy and earthy. Peanut oil, dry coconut, tiny
                lavangi chillies are the trademark of their cooking. But the
                foolproof way to tell a Khandeshi dish from another is to look
                for oil swimming over the dish, locally and lovingly called
                tarri. Kala masala is to the Khandeshis what bottle masala is to
                East Indians. Every family has its own version of the recipe
                that's pounded every summer and bottled for use all year long.
                It's a heavily roasted preparation and includes khopra,
                coriander seeds, dried red chillies, peppercorns, whole
                turmeric, cinnamon, cloves, black cardamom, shahjeera, fennel
                seeds, hing, khus khus, bay leaves, nutmeg, mace, dagad phool,
                dry ginger and jeera. Pumpkins, green tomatoes, green sorrel
                leaves, ridge gourd and the very popular brinjal are all sourced
                on the day of cooking." The Khandeshi baingan bharta or hirva
                vangyachi bharith is made with green brinjals (long, slim,
                striped variety commonly found in Jalgaon) that are roasted on
                an open flame till black. They are then pulped and pounded with
                green chillies, garlic, peanuts and spring onions. Bharleli
                vaangi, another popular brinjal preparation, involves stuffing
                aubergine with a paste of roasted peanuts, dried coconut,
                garlic, turmeric, red chilli powder and kala masala. But the
                most famous and easiest Khandeshi bhaji is made without
                vegetables. Shev bhaji is a curry made with dry coconut, garlic
                and onions. The crisp shev absorbs the spicy curry and oil,
                making it ideal to slurp up with the bhakri.
              </p>
            </div>
           <div className="icons">
              <SocialIcon url="https://twitter.com"/>
              <SocialIcon url="https://whatsapp.com"/>
              <SocialIcon url="https://instagram.com"/>
              <SocialIcon url="https://facebook.com"/>
              <SocialIcon url="https://telegram.com"/>
           
           </div>
           
            {/* <div className="col item social">
              <a href="#">
                <i className="icon ion-social-whatsapp"></i>
              </a>
              <a href="#">
                <i className="icon ion-social-instagram"></i>
              </a>
              <a href="#">
                <i className="icon ion-social-facebook"></i>
              </a>
              <a href="#">
                <i className="icon ion-social-twitter"></i>
              </a>
            </div> */}
          </div>
          <p className="copyright">
            2022 @ Thali of India. All rights reserved
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Footer;