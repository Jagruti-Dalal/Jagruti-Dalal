In the exercise files, I have set up a simple ReactJS application that models a user’s bank application.

Have a good look at the mockup. In addition to the the user being able to view their total balance, they can also perform withdrawal actions

The name and balance of the user are stored in the application state.

There are two things you need to do.

(i) Refactor the App’s state to be managed solely by Redux.

(ii) Handle the withdrawal actions to actually deplete the user’s balance i.e on clicking the buttons, the balance reduces.

NB: you must do this via Redux only.

