import React from 'react';
import { Withdraw } from './Bankinfo/Bankinfo';

function App() {
  return (
   <>
<Withdraw/>

   </>
        
  );
}

export default App;
