import { configureStore } from '@reduxjs/toolkit';
import bankinfoSliceReducer from './Bankinfo/BankinfoSlice';

export const store = configureStore({
  reducer: {
    Withdraw: bankinfoSliceReducer,
  },
});
